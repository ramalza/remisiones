# Ramalza · Sistema de Remisiones

App móvil para registro de remisiones de conectores mecánicos.

- Registra entregas con foto
- Actualiza inventario automáticamente  
- Envía correos a 7 destinatarios
- Integración con Google Sheets
